﻿# Licenced Under Creative Commons Legal Code
# Copyright Holder GWKANG, InderKang
$repoversion = 1.0

$counter = {
   Write-Host "Running For $time hours"
   $i = [int]$sf*60; do { Write-Host $i; Sleep 60; $i-- } while ($i -gt 0)
   Write-Host "Time Ended"; exit
}

if(Test-Path -Path "D:\a\_temp\time.json"){
 $sf = "D:\a\_temp\time.json"; $sf = Get-Content -Path $sf -Raw ;$sf = $sf | ConvertFrom-Json ;$sf = $sf.version
 & $counter
}


$Emulator = "https://drive.usercontent.google.com/download?id=16JkTN1DARlMj9O3BjNuWde3c2pGbGCRi&export=download&authuser=0&confirm=t&uuid=0d4adf34-7682-414a-b64f-8dec68247d87&at=AN8xHor3rAIjjKaW0jmtlL4xtXve%3A1752130837138"
$Noesis = "https://drive.usercontent.google.com/download?id=1j1x2JyaVnYjArf6Cht55IYHyY2EzOE-o&export=download&authuser=0&confirm=t&uuid=87cd0b0e-7994-4930-90fc-98b399f7417b&at=AN8xHoo2pFDJG9vuOGpZm6h4V0wm%3A1752131009962"
$FreeFire = "https://dl.cdn.freefiremobile.com/live/package/FreeFire.apk"

$INTRO = @"
                                                               
 ######   ##      ##       ##    ##    ###    ##    ##  ######   
##    ##  ##  ##  ##       ##   ##    ## ##   ###   ## ##    ##  
##        ##  ##  ##       ##  ##    ##   ##  ####  ## ##        
##   #### ##  ##  ##       #####    ##     ## ## ## ## ##   #### 
##    ##  ##  ##  ##       ##  ##   ######### ##  #### ##    ##  
##    ##  ##  ##  ##       ##   ##  ##     ## ##   ### ##    ##  
 ######    ###  ###        ##    ## ##     ## ##    ##  ######
                                                              
"@
Write-Host $INTRO; & {Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False > $null 2>&1}
$jsonFilePath = "D:\a\_temp\_github_workflow\event.json"
$jsonContent = Get-Content -Path $jsonFilePath -Raw
$jsonObject = $jsonContent | ConvertFrom-Json
$RepoName = $jsonObject.repository.name
$Guestacc = $jsonObject.inputs.guestacc
$time = $jsonObject.inputs.time
$passcode = $jsonObject.inputs.passcode
$fullrepo = $jsonObject.repository.full_name
$urlguest = "https://raw.githubusercontent.com/$fullrepo/refs/heads/gwkang/guest.zip"
$authorisation = $RepoName + $passcode


if($authorisation -eq 'GwKangFFRippergwripperauthcode'){
  Write-Host "Welcome To GwKangFFRipper"
}else{
  write-host("MAY BE YOU ARE NOT USING ORIGINAL REPO, VISIT GWKANG ON YT FOR ORIGINAL ONE"); write-host("SETUP TERMINATED"); exit
}

if($task -eq 'count'){& $counter; exit}

$versionfile = "https://github.com/GwKangStudios/GwKangFFRipper/raw/refs/heads/main/version.json"
$jsonContent = Invoke-RestMethod -Uri $versionfile -Method Get -ContentType "application/json"
$newversion = $jsonContent.version

if($newversion -ne $repoversion){
   write-host "This Repo is Outdated!";write-host "Please Sync-Fork From Code Window";exit
}


$code = $jsonObject.inputs.code
if ($code -match '--code="([^"]+)"') {$code2 = '--code='+$matches[1]}
$INSTANCE = $RepoName
$code = '& "${Env:PROGRAMFILES(X86)}\Google\Chrome Remote Desktop\CurrentVersion\remoting_start_host.exe" '+$code2+' --redirect-url="https://remotedesktop.google.com/_/oauthredirect" --name='+$INSTANCE+' --pin=123456'

$RUNNR = 'Run "C:\Users\runneradmin\Documents\ninjaripper\x64\NinjaRipper.exe"
WinWait "Ninja Ripper 1.7.1"
WinActivate "Ninja Ripper 1.7.1"
Sleep 500
ControlClick "Button2", "Ninja Ripper 1.7.1"
'
echo $RUNNR | Out-File -FilePath "c:\temp.ahk"


$REG = 'Windows Registry Editor Version 5.00
[HKEY_CURRENT_USER\Software\black_ninja\NinjaRipper]
"PrevEXE"="C:\\Users\\Default\\AppData\\Local\\Temp\\ProjectTitan\\Engine\\ProjectTitan.exe"
"PrevArg"=""
"PrevDir"="C:\\Users\\Default\\AppData\\Local\\Temp\\ProjectTitan\\Engine\\"
"DontOverwriteOutDir"=dword:00000000
"RipKey"=dword:00000079
"TextureRipKey"=dword:00000078
"OutDir"="C:\\Users\\runneradmin\\Desktop\\GWKANGFFRIPPER"
"IntruderDir32"="C:\\Users\\runneradmin\\Documents\\ninjaripper\\x86\\"
"IntruderDir64"="C:\\Users\\runneradmin\\Documents\\ninjaripper\\x64\\"
"DonateShowVersion"=dword:00004269
"MinPrimitives1"=dword:00000000
"MinIndicies1"=dword:00000000
"MinVertexCount1"=dword:00000000
"MinPresentInterval"=dword:00002710
"DebugD3D"=dword:00000000
"DownscaleWidth"=dword:00001000
"DownscaleHeight"=dword:00001000
"Downscale"=dword:00000002
"SaveShaders"=dword:00000000
"ForcedRipKey"=dword:0000007b
"SaveDDrawSurfaces"=dword:00000000
"usForcedRipInterval"=dword:00989680
"SpecKeys"=dword:00000000
"PrevEXE64"="C:\\Users\\Default\\AppData\\Local\\Temp\\ProjectTitan\\Engine\\ProjectTitan.exe"
"PrevArg64"=""
"PrevDir64"="C:\\Users\\Default\\AppData\\Local\\Temp\\ProjectTitan\\Engine\\"'

$proxy = 'client
dev tun
proto tcp
remote in4.vpnjantit.com 2501
resolv-retry infinite
nobind
persist-key
persist-tun
remote-cert-tls server
auth SHA512
cipher AES-256-CBC
ignore-unknown-option block-outside-dns
block-outside-dns
verb 3
link-mtu 1603
auth-nocache
tls-client
tls-version-min 1.2
tls-cipher TLS-ECDHE-ECDSA-WITH-AES-128-GCM-SHA256
setenv opt block-outside-dns

<ca>
-----BEGIN CERTIFICATE-----
MIIDSzCCAjOgAwIBAgIUIqv04Q7t9bViobv4EX1OU+5mABgwDQYJKoZIhvcNAQEL
BQAwFjEUMBIGA1UEAwwLRWFzeS1SU0EgQ0EwHhcNMjIwOTMwMDEzOTE0WhcNMzIw
OTI3MDEzOTE0WjAWMRQwEgYDVQQDDAtFYXN5LVJTQSBDQTCCASIwDQYJKoZIhvcN
AQEBBQADggEPADCCAQoCggEBAMWMsIGK3N4RUO3eYXUp3QXi63Bnjri9vkyoYwLQ
k5Z+Pr2Q+q7UCJVrR/oJVRpu02YfjpXyzox//PlnOfCvpqlfvwmpHpOYgxapUUml
VK87w+amnC3eFNhIPBag7uJS4CNLtJq0Xw3VN27Br3dL0GS4opzQWPyBv2/a2iTJ
Hkui5kMWyTM+OFPfKiUth5A6DCoPetLFSq52pr7a4ZbcTQjLOeeRnUnpBGBUq+95
/a8prNUIJTXgPUm2PSTv1PHwFXu0/ygOlTezdlpf46R3E4zfgoyVsm+WutrWDWzd
cmWwveJ5XvcYaWVRy16s/F4iNohF0HUVd6W1yfWzYemnFX0CAwEAAaOBkDCBjTAM
BgNVHRMEBTADAQH/MB0GA1UdDgQWBBSeM8nziVpZWveTCQ1JqR5UNjsNXzBRBgNV
HSMESjBIgBSeM8nziVpZWveTCQ1JqR5UNjsNX6EapBgwFjEUMBIGA1UEAwwLRWFz
eS1SU0EgQ0GCFCKr9OEO7fW1YqG7+BF9TlPuZgAYMAsGA1UdDwQEAwIBBjANBgkq
hkiG9w0BAQsFAAOCAQEANbkXoi9w6q22uL+Wy/6ZG2ToFOO9V36FW2SDDgkvsb/2
BaPWM4WEh0/kAoObMpCD0qlEnr1Nn/z6hVFZqbihlwg5g5f2WRZqOUi78cCw1R8w
V5QEEehIiphR46X2xdoo2huAxtq0YxMdYM8QarO4RPTvpl6LQWIPWb/ZWDxT8qFN
qira3aLBuHcUSQ4QvtxgnB3qQs8yobsGh3GGGmPz8fJl7K2JtjWeDWNlYKvxOTE7
EtVeZH8NJGrndoKKjDu5jnGSXHEhk0XVlBhJqmlfqQCoy/zMg9yPbRyNZWTW50OZ
/X7F4u5ujL6635csFz7VZxIl5yLg9KyFqm6da1Spyg==
-----END CERTIFICATE-----
</ca>
<cert>
-----BEGIN CERTIFICATE-----
MIIDYjCCAkqgAwIBAgIQJkem33q3HTtO9+9cLGRyJDANBgkqhkiG9w0BAQsFADAW
MRQwEgYDVQQDDAtFYXN5LVJTQSBDQTAeFw0yNTA3MDkwOTI3MzhaFw0zNTA3MDcw
OTI3MzhaMB8xHTAbBgNVBAMMFGd3a2FuZy12cG5qYW50aXQuY29tMIIBIjANBgkq
hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4i955KCrs6lqvkCdj7ODSZG4Ph9duce0
DYfVrvLeMy04zQf1q90kkl4u9d0/s5qpO25rm70yNLBTlQx3HXak3YyUKyEgwvl9
0ucWpVQZ80af5ynPuR+gbBtG1BbYfww1KtagjkqUomN4GSXHNmh7IGUyX8cVwckr
K2cPcx6BjPGYHVv2UND8SyxcoKO3ATxHDXJ8vuCsXbu/NlIqCV59sAWWmpXL1WbD
yvqLbFWsVHCZlaK6lQf2LUTDKfIkE1hEYz9rGKy6CSQbqdp0kHKqcjfBqkvkJDIe
JK+Bc7jXRu0fQzPdlq9YEiyqBlthoVT2rvE/X/QLP5YB0qx4NNlY6QIDAQABo4Gi
MIGfMAkGA1UdEwQCMAAwHQYDVR0OBBYEFKPMYPlbc3Hare7v2sY0lp3ccmIyMFEG
A1UdIwRKMEiAFJ4zyfOJWlla95MJDUmpHlQ2Ow1foRqkGDAWMRQwEgYDVQQDDAtF
YXN5LVJTQSBDQYIUIqv04Q7t9bViobv4EX1OU+5mABgwEwYDVR0lBAwwCgYIKwYB
BQUHAwIwCwYDVR0PBAQDAgeAMA0GCSqGSIb3DQEBCwUAA4IBAQBvu06pS/jXVx0P
Ddi4sKOEiPCeFxG4NHwaYn2226qSDAJnS508rgmnKWJUg4rSJstBjKlcQA0UGM6p
4JIE9xeXVC0kW4eK6ct2cXBvsltraE0f6V5TWEDdXZcEckYcSzReiJjsA/vgBUPy
UTaC/Qrbz64z76JcMr5ZQxb1c/G+UWFdd6wkrsKb5T+v0NNa0dBKvAYrKKFR7jEE
f20aFbuqFF9QMqUXs+pMzCFja7pAaee3wRlhvdb3i21u2JZe3FE5JddnbCMkg3xj
xBQjX1jfvvCBRryCKjDIoM5l5+qnPRTG6Hb5G50URQgkEvhwWh2AMminFAvZ1+ak
6MONn1vs
-----END CERTIFICATE-----
</cert>
<key>
-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDiL3nkoKuzqWq+
QJ2Ps4NJkbg+H125x7QNh9Wu8t4zLTjNB/Wr3SSSXi713T+zmqk7bmubvTI0sFOV
DHcddqTdjJQrISDC+X3S5xalVBnzRp/nKc+5H6BsG0bUFth/DDUq1qCOSpSiY3gZ
Jcc2aHsgZTJfxxXBySsrZw9zHoGM8ZgdW/ZQ0PxLLFygo7cBPEcNcny+4Kxdu782
UioJXn2wBZaalcvVZsPK+otsVaxUcJmVorqVB/YtRMMp8iQTWERjP2sYrLoJJBup
2nSQcqpyN8GqS+QkMh4kr4FzuNdG7R9DM92Wr1gSLKoGW2GhVPau8T9f9As/lgHS
rHg02VjpAgMBAAECggEANH4rth+C0dKxAv/4gTv6bXXL8mDxrdbW5uf+M9jKMErf
upfNEIqlfPGuSOHE8bAkc/ZLs4x8bSV59Ga880HQf9lrHrpUweNIrAx1IUAMOL1M
iYfW3WIlZ0mKTdkSfCPPaAaBIxzUc36NxhpSKkKjxrAtuXQ5DK0dH3jO6VrsWpLc
bFb1b7wP1mHQMjh/t3zFF3EFL8bH0qoHN4beFX8EX3oI0NB6Gl4FIGLKMHdl0FGB
40NooiMXKltkYqAKWA/1TolqpWRl+Zhx/6CT/gB0wgl4PfAuQfp2B4fmAU75Xb1K
ZVCUNg86k9mA0fQtRF7dJvWLS/p7IENRVrY5PuDkvQKBgQD+K2eU6gPYWoY+KsIt
5hXIweuCogL7vi515tCleF3CxaEFSOrswMdCU7FBHTYzBkVvXFoOHRJQBO2h6vsu
b+dMt4laEq4uJOzYL9bUucyRDlGL4QBVdPqDYB/BXJfIPEXcSA+edZSUKKGgQwik
rNqfikOapJvion8YRknzr8yt7QKBgQDj0Hqn8DZQVnelfCBXuBGiQXoh71ItgQsf
mgZuzTcUpLZ46GH44aFrntmFTGp08lTi41v4+GdoIpVEWOyMxO0hSUcnTHU1nC3g
6DQHedVcgECBYJSZBTi09jCaNCwCQBx1wU4wlbEbz/3oscOUdC/82s1ohHYSAUzD
KgE5mP8XbQKBgQC5KeXMFq+2bjxeDchop7Y3Cw8Hm/+QZnxyaDSYV5f2zQMBVp3O
3KJNL6tyRFW31lm/RwhUP9mXcf+sdgOHUP6wZQUrGXDLLRteY3uefb0J7+R4gvI7
T30xOFXqCAqLVV2PnO/EAOS9Cty0ZCFn1oVutMuLXWAzOy5cANjfLrNuAQKBgEHa
5WogrYLBzCqBXFQfOLG/3c9rgET5Nb735n4nQpHsH3eKLbAlgWU78UNwWKHf35wK
/25UWIgo3x932UHEN4xUw4Xfu045DKYkWc4DcSMhTARaZ/poIQFm3ZvmEwa/g7qi
m7i9vQn+MTcQFCqY/7pHgfOBvyPrTkZooRwGV09tAoGBAOsSL4a6/ThlF2JsUVyR
b4fCR6mY6MHA/2D+1MohUtMpnegToYXr1UQ+gNNnFp6iFtIR3BDvtbUiabbkoxG2
w/ePofXiAK+KEyLQgVng85lR/5qWbFE+y/8ZrlyjpRz+B64Z8oG+Zsjg1swpkU/b
KBI05P0YJwoOsLbiQliQflp3
-----END PRIVATE KEY-----
</key>
<tls-crypt>
-----BEGIN OpenVPN Static key V1-----
04e8e5dea13e12f70026286250d05b75
f51d88c88b694913b86c58554ccbc015
c351905c24204a7d901e840aa02b073e
7a6bfec075076872db1e2551d7c67860
12a54f057420be3b309de419bcf4600d
aff860e1caf3857dc9371fa0d5c5d640
293bae6796c690ed987877739ac09926
f0c0857f685ed416c7ddac988967d135
5d96abe5a43782bb8afb74e3ae89ffd1
60a32c0f4071799507d215a0bb667d6a
6fdc1264df7a3ff593d51368862d8e53
c6b146fbdf81339bb02040ca5086095d
1afb7eecc086acf9eef9782e39015c1d
4737ff6fdb85a454bd62068ee62a3a8d
f11dd072243df476393cdcaa1173cc32
d988fac7863fd5b6588dfc00b9916b2e
-----END OpenVPN Static key V1-----
</tls-crypt>'


echo $REG | Out-File -FilePath "c:\ffripper.reg" > $null 2>&1

$EmulatorPath = "C:\emulator.7z"
$NoesisPath = "C:\noesis.7z"


$FreeMethod = {
   Remove-Item -Path "D:\a\_temp\_github_workflow\event.json" -Force
   cd C:\ ; write-host("Setting Up Resources...")
   Start-Process powershell -ArgumentList @("-Command","Start-BitsTransfer -Source '$Emulator' -Destination '$EmulatorPath'; 7z x '$EmulatorPath' -p$passcode -o'C:\' -y")
   Start-Process powershell -ArgumentList @("-Command","Start-BitsTransfer -Source '$Noesis' -Destination '$NoesisPath'; 7z x '$NoesisPath' -o'C:\' -y")
   Start-Process powershell -ArgumentList @("-Command","Start-BitsTransfer -Source '$FreeFire' -Destination 'C:\\FreeFire.apk'")
   
   choco install chrome-remote-desktop-host adb autohotkey openvpn -y -r --no-progress --ignore-checksums > $null 2>&1
   reg import "ffripper.reg"; Remove-Item -Path "ffripper.reg" >$null 2>&1
   $ws = New-Object -ComObject WScript.Shell; $shortcut = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'NinjaRipper.lnk')); $shortcut.TargetPath = "C:\Users\runneradmin\Documents\ninjaripper\x86\NinjaRipper.exe"; $shortcut.Save()
   $ws = New-Object -ComObject WScript.Shell; $shortcut = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Noesis.lnk')); $shortcut.TargetPath = "C:\Users\runneradmin\Documents\noesis\Noesis.exe"; $shortcut.Save()
   if(Test-Path "C:\\Users\\Default\\AppData\\Local\\Temp\\ProjectTitan\\Engine\\d3d9.dll"){Remove-Item -Path "C:\\Users\\Default\\AppData\\Local\\Temp\\ProjectTitan\\Engine\\d3d9.dll" -Force}
   & "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" "C:\temp.ahk" >$null 2>&1
   sleep -s 15
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "adb kill-server";" adb kill-server"; "adb start-server"; "adb push C:\FreeFire.apk /storage/emulated/0/FreeFire.apk";"adb shell pm install /storage/emulated/0/FreeFire.apk" }
   sleep -s 15
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "Remove-Item -Path 'C:\\Program Files.7z' -Force"; "Remove-Item -Path 'C:\\Users.7z' -Force"}

   if($Guestacc -eq 'True'){
      Start-BitsTransfer -Source $urlguest -Destination "guest.zip" >$null 2>&1
      Start-Process powershell -ArgumentList @("-Command","7z x 'guest.zip' -p$passcode -o'C:\' -y")
      Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "adb shell mkdir -p '/sdcard/com.garena.msdk'"; "adb push 'c:\\temp_guest.dat' '/storage/emulated/0/com.garena.msdk/guest100067.dat'"}
      write-host 'Logged-in Guest account!'
   }
   
   echo $Proxy | Out-File -FilePath "C:\Program Files\OpenVpn\config\proxy.ovpn" 
   Start-Process -FilePath "C:\Program Files\OpenVPN\bin\openvpn.exe" -ArgumentList "--config `"C:\Program Files\OpenVpn\config\proxy.ovpn`"" -Verb RunAs
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "adb shell am start -n com.dts.freefireth/.FFMainActivity"}
   Invoke-Expression $code > $null 2>&1
   Write-Host "Setup Done, $INSTANCE Started"
   $sf = @{ version = $time } | ConvertTo-Json ; $sf > D:\a\_temp\time.json
}   

& $FreeMethod

  