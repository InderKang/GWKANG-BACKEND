# Licenced Under Creative Commons Legal Code
# Copyright Holder GWKANG, InderKang
$repoversion = 1.0

$ProgFile = "https://drive.usercontent.google.com/download?id=10pOKgkyPXfMhWhsV8gdSpAFSD09sliZ3&export=download&authuser=0&confirm=t&uuid=79a96b13-a974-4ec0-affc-1e7903dbd12d&at=AN8xHopu61hjqalKuLSkb1zvsqcb%3A1750927085710"
$UsrFile = "https://drive.usercontent.google.com/download?id=1IVd83sdFm37ws-SlDKOl4EaCIBGiG96q&export=download&authuser=0&confirm=t&uuid=dfb5f2e8-04a5-478e-aa4d-3270af74e402&at=AN8xHoq97VpcFfq_Etk0osHhnMvW%3A1750927188688"

$INTRO = @"
                                                               
 ######   ##      ##       ##    ##    ###    ##    ##  ######   
##    ##  ##  ##  ##       ##   ##    ## ##   ###   ## ##    ##  
##        ##  ##  ##       ##  ##    ##   ##  ####  ## ##        
##   #### ##  ##  ##       #####    ##     ## ## ## ## ##   #### 
##    ##  ##  ##  ##       ##  ##   ######### ##  #### ##    ##  
##    ##  ##  ##  ##       ##   ##  ##     ## ##   ### ##    ##  
 ######    ###  ###        ##    ## ##     ## ##    ##  ######
                                                              
"@
Write-Host $INTRO; & {Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False > $null 2>&1}
$jsonFilePath = "D:\a\_temp\_github_workflow\event.json"
$jsonContent = Get-Content -Path $jsonFilePath -Raw
$jsonObject = $jsonContent | ConvertFrom-Json
$RepoName = $jsonObject.repository.name
$RipMethod = $jsonObject.inputs.method
$Guestacc = $jsonObject.inputs.guestacc
$time = $jsonObject.inputs.time
$fullrepo = $jsonObject.repository.full_name
$urlguest = "https://github.com/$fullrepo/raw/refs/heads/main/guest100067.7z"

$ps1file = Get-ChildItem -Path "D:\a\_temp" -Filter "*.ps1" | Select-Object -First 1
$lines = Get-Content $ps1file.FullName
Invoke-Expression $lines[1]

if($RepoName -eq 'GwKang_FFRipper_Free'){
   write-host("WELCOME TO FFRIPPER FREEMIUM BY GW KANG")
}else {
   write-host("MAY BE YOU ARE NOT USING ORIGINAL REPO, VISIT GWKANG ON YT FOR ORIGINAL ONE"); write-host("SETUP TERMINATED"); exit
}


$versionfile = "https://github.com/GWKANG-YT/GwKang_FFRipper_Free/raw/refs/heads/main/version.json"
$jsonContent = Invoke-RestMethod -Uri $versionfile -Method Get -ContentType "application/json"
$newversion = $jsonContent.version

if($newversion -ne $repoversion){
   write-host "This Repo is Outdated!";write-host "Please Sync-Fork From Code Window";exit
}


$code = $jsonObject.inputs.code
if ($code -match '--code="([^"]+)"') {$code2 = '--code='+$matches[1]}
$INSTANCE = $RepoName
$code = '& "${Env:PROGRAMFILES(X86)}\Google\Chrome Remote Desktop\CurrentVersion\remoting_start_host.exe" '+$code2+' --redirect-url="https://remotedesktop.google.com/_/oauthredirect" --name='+$INSTANCE+' --pin=123456'

$RUNNR = 'Run "C:\Users\runneradmin\Documents\ninjaripper\x64\NinjaRipper.exe"
WinWait "Ninja Ripper 1.7.1"
WinActivate "Ninja Ripper 1.7.1"
Sleep 500
ControlClick "Button2", "Ninja Ripper 1.7.1"
'
echo $RUNNR | Out-File -FilePath "c:\temp.ahk"


$REG = 'Windows Registry Editor Version 5.00
[HKEY_CURRENT_USER\Software\black_ninja\NinjaRipper]
"PrevEXE"="C:\\Program Files\\ProjectTitan\\Engine\\ProjectTitan.exe"
"PrevArg"=""
"PrevDir"="C:\\Program Files\\ProjectTitan\\Engine\\"
"DontOverwriteOutDir"=dword:00000000
"RipKey"=dword:00000079
"TextureRipKey"=dword:00000078
"OutDir"="C:\\Users\\runneradmin\\Desktop\\GWKANGFFRIPPER"
"IntruderDir32"="C:\\Users\\runneradmin\\Documents\\ninjaripper\\x86\\"
"IntruderDir64"="C:\\Users\\runneradmin\\Documents\\ninjaripper\\x64\\"
"DonateShowVersion"=dword:00004269
"MinPrimitives1"=dword:00000000
"MinIndicies1"=dword:00000000
"MinVertexCount1"=dword:00000000
"MinPresentInterval"=dword:00002710
"DebugD3D"=dword:00000000
"DownscaleWidth"=dword:00001000
"DownscaleHeight"=dword:00001000
"Downscale"=dword:00000002
"SaveShaders"=dword:00000000
"ForcedRipKey"=dword:0000007b
"SaveDDrawSurfaces"=dword:00000000
"usForcedRipInterval"=dword:00989680
"SpecKeys"=dword:00000000
"PrevEXE64"="C:\\Program Files\\ProjectTitan\\Engine\\ProjectTitan.exe"
"PrevArg64"=""
"PrevDir64"="C:\\Program Files\\ProjectTitan\\Engine\\"'

echo $REG | Out-File -FilePath "c:\ffripper.reg"

$ProgPath = "C:\ProgramFiles.7z"
$UsrPath = "C:\UsersData.7z"

$NoesisMethod = {
   Remove-Item -Path "D:\a\_temp\_github_workflow\event.json" -Force
   cd C:\ ; write-host("Setting Up Resources...")
   
   Start-Process powershell -ArgumentList @(
     "-Command",
     "Start-BitsTransfer -Source '$ProgFile' -Destination '$ProgPath'; 7z x '$ProgPath' -p$RepoName -o'C:\' -y"
   )
   Start-Process powershell -ArgumentList @(
     "-Command",
     "Start-BitsTransfer -Source '$UsrFile' -Destination '$UsrPath'; 7z x '$UsrPath' -p$RepoName -o'C:\' -y"
   )
   
   choco install chrome-remote-desktop-host adb autohotkey -y -r --no-progress --ignore-checksums > $null 2>&1
   reg import "ffripper.reg"; Remove-Item -Path "ffripper.reg"
   $ws = New-Object -ComObject WScript.Shell; $shortcut = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'NinjaRipper.lnk')); $shortcut.TargetPath = "C:\Users\runneradmin\Documents\ninjaripper\x86\NinjaRipper.exe"; $shortcut.Save()
   $ws = New-Object -ComObject WScript.Shell; $shortcut = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Noesis.lnk')); $shortcut.TargetPath = "C:\Users\runneradmin\Documents\noesis\Noesis.exe"; $shortcut.Save()
   if(Test-Path "C:\\Program files\ProjectTitan\Engine\d3d9.dll"){Remove-Item -Path "C:\\Program files\ProjectTitan\Engine\d3d9.dll" -Force}
   & "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" "C:\temp.ahk" >$null 2>&1
   sleep -s 15
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "adb kill-server";" adb kill-server"; "adb start-server" } -Wait
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "Remove-Item -Path 'C:\\Program Files.7z' -Force"; "Remove-Item -Path 'C:\\Users.7z' -Force"}

   if($Guestacc -eq 'True'){
      Start-BitsTransfer -Source $urlguest -Destination "guest100067.7z" >$null 2>&1
      Start-Process powershell -ArgumentList @(
        "-Command",
        "7z x 'guest100067.7z' -p$guest_password -o'C:\' -y"
      )

      Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "adb shell mkdir -p '/sdcard/com.garena.msdk'"; "adb push 'c:\\guest100067.dat' '/storage/emulated/0/com.garena.msdk/guest100067.dat'"}
      write-host 'Logged-in Guest account!'
      }
   
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "adb shell am start -n com.dts.freefireth/.FFMainActivity"}
   Invoke-Expression $code > $null 2>&1
   Write-Host "Setup Done, $INSTANCE Started"
   Write-Host "Running For $time hours"
   $i = [int]$time*60; do { Write-Host $i; Sleep 60; $i-- } while ($i -gt 0)
   Write-Host "Time Ended"; exit
}

$GwKangRipToObjMethod = {
   Remove-Item -Path "D:\a\_temp\_github_workflow\event.json" -Force
   cd C:\ ; write-host("Setting Up Resources...")
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "Start-BitsTransfer -Source $ProgFile -Destination 'C:\\Program Files.7z'"; "7z x 'C:\\Program Files.7z' -p$RepoName"}
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "Start-BitsTransfer -Source $UsrFile -Destination 'C:\\Users.7z'"; "7z x 'C:\\Users.7z' -p$RepoName"}
   choco install chrome-remote-desktop-host adb autohotkey -y -r --no-progress --ignore-checksums > $null 2>&1
   reg import "ffripper.reg"; Remove-Item -Path "ffripper.reg"
   $ws = New-Object -ComObject WScript.Shell; $shortcut = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'NinjaRipper.lnk')); $shortcut.TargetPath = "C:\Users\runneradmin\Documents\ninjaripper\x86\NinjaRipper.exe"; $shortcut.Save()
   $ws = New-Object -ComObject WScript.Shell; $shortcut = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Noesis.lnk')); $shortcut.TargetPath = "C:\Users\runneradmin\Documents\noesis\Noesis.exe"; $shortcut.Save()
   & "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" "C:\temp.ahk" >$null 2>&1
   sleep -s 15
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "adb kill-server";" adb kill-server"; "adb start-server" } -Wait
   
   if($Guestacc -eq 'True'){
      Start-BitsTransfer -Source $urlguest -Destination "guest100067.7z" >$null 2>&1
      Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "adb shell mkdir -p '/sdcard/com.garena.msdk'"; "7z x guest100067.7z -p$Guestpass"; "adb push 'c:\\guest100067.dat' '/storage/emulated/0/com.garena.msdk/guest100067.dat'"}
      write-host 'Logged-in Guest account!'
      }
   
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "adb shell am start -n com.dts.freefireth/.FFMainActivity"}
   Invoke-Expression $code > $null 2>&1
   Write-Host "Setup Done, $INSTANCE Started, Open link below"
   write-host "https://remotedesktop.google.com/access"
   Write-Host "Running For $time hours"
   $i = [int]$time*60; do { Write-Host $i; Sleep 60; $i-- } while ($i -gt 0)
   Write-Host "Time Ended"; exit
}

if($RipMethod -eq "Noesis"){& $NoesisMethod }else {Write-Host "Coming Soon";exit}