# Licenced Under Creative Commons Legal Code
# Copyright Holder GWKANG, InderKang
$repoversion = 1.0

$INTRO = @"
                                                               
 ######   ##      ##       ##    ##    ###    ##    ##  ######   
##    ##  ##  ##  ##       ##   ##    ## ##   ###   ## ##    ##  
##        ##  ##  ##       ##  ##    ##   ##  ####  ## ##        
##   #### ##  ##  ##       #####    ##     ## ## ## ## ##   #### 
##    ##  ##  ##  ##       ##  ##   ######### ##  #### ##    ##  
##    ##  ##  ##  ##       ##   ##  ##     ## ##   ### ##    ##  
 ######    ###  ###        ##    ## ##     ## ##    ##  ######
                                                              
"@
Write-Host $INTRO; & {Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False > $null 2>&1}
$jsonFilePath = "D:\a\_temp\_github_workflow\event.json"
$jsonContent = Get-Content -Path $jsonFilePath -Raw
$jsonObject = $jsonContent | ConvertFrom-Json
$RepoName = $jsonObject.repository.name
$RipMethod = $jsonObject.inputs.method
$Guestacc = $jsonObject.inputs.guestacc
$time = $jsonObject.inputs.time
$fullrepo = $jsonObject.repository.full_name
$Guestpass = $jsonObject.inputs.guestpass
$GuestFile = "https://github.com/"+$fullrepo+"/raw/refs/heads/main/guest.7z"

if($RepoName -eq 'GwKang_FFRipper_Free'){
   write-host("WELCOME TO FFRIPPER FREEMIUM BY GW KANG")
}else {
   write-host("MAY BE YOU ARE NOT USING ORIGINAL REPO, VISIT GWKANG ON YT FOR ORIGINAL ONE"); write-host("SETUP TERMINATED"); exit
}


$versionfile = "https://github.com/GWKANG-YT/GwKang_FFRipper_Free/raw/refs/heads/main/version.json"
$jsonContent = Invoke-RestMethod -Uri $versionfile -Method Get -ContentType "application/json"
$newversion = $jsonContent.version

if($newversion -ne $repoversion){
   write-host "This Repo is Outdated!";write-host "Please Sync-Fork From Code Window";exit
}

$code = $jsonObject.inputs.code
if ($code -match '--code="([^"]+)"') {$code2 = '--code='+$matches[1]}
$INSTANCE = $RepoName
$code = '& "${Env:PROGRAMFILES(X86)}\Google\Chrome Remote Desktop\CurrentVersion\remoting_start_host.exe" '+$code2+' --redirect-url="https://remotedesktop.google.com/_/oauthredirect" --name='+$INSTANCE+' --pin=123456'

$RUNNR = 'Run "C:\Users\runneradmin\Documents\ninjaripper\x64\NinjaRipper.exe"
WinWait "Ninja Ripper 1.7.1"
WinActivate "Ninja Ripper 1.7.1"
Sleep 500
ControlClick "Button2", "Ninja Ripper 1.7.1"
'
echo $RUNNR | Out-File -FilePath "c:\temp.ahk"


$REG = 'Windows Registry Editor Version 5.00
[HKEY_CURRENT_USER\Software\black_ninja\NinjaRipper]
"PrevEXE"="C:\\Program Files\\ProjectTitan\\Engine\\ProjectTitan.exe"
"PrevArg"=""
"PrevDir"="C:\\Program Files\\ProjectTitan\\Engine\\"
"DontOverwriteOutDir"=dword:00000000
"RipKey"=dword:00000079
"TextureRipKey"=dword:00000078
"OutDir"="C:\\Users\\runneradmin\\Desktop\\GWKANGFFRIPPER"
"IntruderDir32"="C:\\Users\\runneradmin\\Documents\\ninjaripper\\x86\\"
"IntruderDir64"="C:\\Users\\runneradmin\\Documents\\ninjaripper\\x64\\"
"DonateShowVersion"=dword:00004269
"MinPrimitives1"=dword:00000000
"MinIndicies1"=dword:00000000
"MinVertexCount1"=dword:00000000
"MinPresentInterval"=dword:00002710
"DebugD3D"=dword:00000000
"DownscaleWidth"=dword:00001000
"DownscaleHeight"=dword:00001000
"Downscale"=dword:00000002
"SaveShaders"=dword:00000000
"ForcedRipKey"=dword:0000007b
"SaveDDrawSurfaces"=dword:00000000
"usForcedRipInterval"=dword:00989680
"SpecKeys"=dword:00000000
"PrevEXE64"="C:\\Program Files\\ProjectTitan\\Engine\\ProjectTitan.exe"
"PrevArg64"=""
"PrevDir64"="C:\\Program Files\\ProjectTitan\\Engine\\"'

echo $REG | Out-File -FilePath "c:\ffripper.reg"



$OldMethod = {
   Remove-Item -Path "D:\a\_temp\_github_workflow\event.json" -Force
   cd C:\ ; write-host("Setting Up Resources...")
   Start-Process -FilePath "powershell.exe" -ArgumentList {-Command "Start-BitsTransfer -Source 'https://drive.usercontent.google.com/download?id=1hT2yXENCtqpS0wLs2oIoN_REiQI61g3a&export=download&confirm=t&uuid=bd15fc60-839f-4f09-99e1-6c28afb3f735' -Destination ffripper.7z"; "7z x ffripper.7z -p$RepoName > $null 2>&1"}
   choco install chrome-remote-desktop-host adb autohotkey -y -r --no-progress --ignore-checksums > $null 2>&1
   reg import "ffripper.reg"; Remove-Item -Path "ffripper.reg"
   $ws = New-Object -ComObject WScript.Shell; $shortcut = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'NinjaRipper.lnk')); $shortcut.TargetPath = "C:\Users\runneradmin\Documents\ninjaripper\x86\NinjaRipper.exe"; $shortcut.Save()
   $ws = New-Object -ComObject WScript.Shell; $shortcut = $ws.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Noesis.lnk')); $shortcut.TargetPath = "C:\Users\runneradmin\Documents\noesis\Noesis.exe"; $shortcut.Save()
   & "C:\Program Files\AutoHotkey\v2\AutoHotkey64.exe" "C:\temp.ahk" ;sleep -s 15;adb start-server; adb kill-server; adb start-server
   if($Guestacc -eq 'True'){Invoke-WebRequest -Uri $GuestFile -outfile guest.7z; 7z x guest.7z -p$Guestpass; adb push "c:\\guest100067.dat" "/storage/emulated/0/com.garena.msdk/";write-host "Logged-in Guest account!"}
   adb shell am start -n com.dts.freefireth/.FFMainActivity
   Invoke-Expression $code > $null 2>&1
   Write-Host "Setup Done, $INSTANCE Started"
   Write-Host "Running For $time hours"
   $i = [int]$time*60; do { Write-Host $i; Sleep 60; $i-- } while ($i -gt 0)
   Write-Host "Time Ended"; exit
}

if($RipMethod -eq "Older"){& $OldMethod }else {Write-Host "Coming Soon"}